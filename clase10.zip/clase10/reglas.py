from errores import ExcepcionLongitud
from errores import ExcepcionMayuscula, ExcepcionMinuscula, ExcepcionNumero, ExcepcionCaracterEspecial, ExcepcionCalisto

class ReglaValidacion:
    def __init__(self, longitud_esperada):
        self._longitud_esperada = longitud_esperada

    def _validar_longitud(self, clave):
        if len(clave) < self._longitud_esperada:  
            raise ExcepcionLongitud("La clave debe tener al menos {} caracteres".format(self._longitud_esperada))

    def _contiene_mayuscula(self, clave):
        if not any(c.isupper() for c in clave):
            raise ExcepcionMayuscula("La clave debe contener al menos una letra mayúscula")

    def _contiene_minuscula(self, clave):
        if not any(c.islower() for c in clave):
            raise ExcepcionMinuscula("La clave debe contener al menos una letra minúscula")

    def _contiene_numero(self, clave):
        if not any(c.isdigit() for c in clave):
            raise ExcepcionNumero("La clave debe contener al menos un número")

class ReglaValidacionGanimedes(ReglaValidacion):
    def contiene_caracter_especial(self, clave):
        caracteres_especiales = {'@', '_', '#', '$', '%'}
        if not any(c in caracteres_especiales for c in clave):
            raise ExcepcionCaracterEspecial("La clave debe contener al menos un caracter especial")

    def es_valida(self, clave):
        self._validar_longitud(clave)
        self._contiene_mayuscula(clave)
        self._contiene_minuscula(clave)
        self._contiene_numero(clave)
        self.contiene_caracter_especial(clave)

class ReglaValidacionCalisto(ReglaValidacion):
    def contiene_calisto(self, clave):
        if "calisto" not in clave.lower():
            raise ExcepcionCalisto("La clave debe contener la palabra 'calisto'")

    def es_valida(self, clave):
        self._validar_longitud(clave)
        self._contiene_numero(clave)
        self.contiene_calisto(clave)


