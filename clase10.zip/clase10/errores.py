class ExcepcionLongitud(Exception):
    pass

class ExcepcionMayuscula(Exception):
    pass

class ExcepcionMinuscula(Exception):
    pass

class ExcepcionNumero(Exception):
    pass

class ExcepcionCaracterEspecial(Exception):
    pass

class ExcepcionCalisto(Exception):
    pass

