from reglas import ReglaValidacionGanimedes, ReglaValidacionCalisto
from errores import ExcepcionLongitud, ExcepcionMayuscula, ExcepcionMinuscula, ExcepcionNumero, ExcepcionCaracterEspecial, ExcepcionCalisto

class Validador:
    def __init__(self, regla):
        self.regla = regla

    def es_valida(self, clave):
        try:
            return self.regla.es_valida(clave)
        except (ExcepcionLongitud, ExcepcionMayuscula, ExcepcionMinuscula, ExcepcionNumero, ExcepcionCaracterEspecial, ExcepcionCalisto) as e:
            return str(e)


if __name__ == "__main__":
    regla_ganimedes = ReglaValidacionGanimedes(8)
    regla_calisto = ReglaValidacionCalisto(6)

    validador_ganimedes = Validador(regla_ganimedes)
    validador_calisto = Validador(regla_calisto)

    clave = "P@ssw0rd"
    
    resultado_ganimedes = validador_ganimedes.es_valida(clave)
    resultado_calisto = validador_calisto.es_valida(clave)

    if resultado_ganimedes is True:
        print("Clave válida según la regla de Validación Ganímedes.")
    else:
        print("Error en la regla de Validación Ganímedes:", resultado_ganimedes)

    if resultado_calisto is True:
        print("Clave válida según la regla de Validación Calisto.")
    else:
        print("Error en la regla de Validación Calisto:", resultado_calisto)
